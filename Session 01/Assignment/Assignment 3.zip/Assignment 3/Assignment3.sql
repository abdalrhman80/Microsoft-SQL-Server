Create database ITI
use ITI

create table Students
(
  Id int primary key identity,
  Fname nvarchar(10) not null,
  Lanme nvarchar(10),
  Age int,
  Address nvarchar(20),
  Dep_Id int,
)

create table Departments
(
  Id int primary  key identity(10,10),
  Dep_Name nvarchar(10) not null,
  Hiring_Date Date,
  Ins_Id int,
)

create table Instructors
(
  Id int primary key identity,
  Name nvarchar(20) not null,
  Address nvarchar(20),
  Bouns int,
  Salary int,
  Hour_Rate int,
  Dep_Id int references Departments(Id),
)

create table Courses
(
  Id int primary key identity,
  Name nvarchar(20) not null,
  Duration dec(6,3),
  Description nvarchar(50),
  Top_Id int, 
)

create table Topics
(
  Id int primary key identity,
  Name nvarchar(20) not null,
)

create table Stu_Course
(
  Stu_Id int references Students(Id),
  Course_Id int references Courses(Id),
  Grade dec(5,2) not null,
  primary key(Stu_Id,Course_Id)
)

create table Course_Instructor
(
  Course_Id int references Courses(Id),
  Ins_Id int references Instructors(Id),
  Evaluation nvarchar(10) not null,
  primary key(Course_Id,Ins_Id)
)

-- Add Foreign key in Students
Alter table Students
Add Foreign key (Dep_Id) references Departments(Id)

-- Add Foreign key in Departments
Alter table Departments
Add Foreign key (Ins_Id) references Instructors(Id)

-- Add Foreign key in Courses
Alter table Courses
Add Foreign key (Top_Id) references Topics(Id)